setwd("~/Documents/Columbia/Courses/Spring/IEOR 4650/Finance insiders")
#setwd("~/Desktop/IEOR 4650 - Business Analytics/Project")
library(cluster)
library(BatchGetSymbols)
library(quadprog)

##############################################################################################
####################################### IMPORT PART ##########################################

# Import the 2007 to 2017 data

SP_data = read.csv('SP_2012_2017.csv',stringsAsFactors = FALSE)
SP_data = na.omit(SP_data)
SP_data = SP_data[,3:5]
colnames(SP_data) = c("Date","Ticker","Price")
SP_data$Date = as.Date(as.character(SP_data$Date),format = "%Y%m%d")

nrow(SP_data[SP_data$Ticker=='AAPL',])
#[1] 1576

# Import the list of tickers
tickers = unique(SP_data$Ticker)

head(SP_data)
colnames(SP_data)
summary(SP_data)

relevant_ticker = vector()
ndays = 1576

# Data frame that will store the log returns
rets = data.frame(matrix(, ncol=(ndays-1), nrow=0))

##############################################################################################
############################### RETURNS GENERATION PART ###################################

for (i in 1:length(tickers)){
  # Get a ticker
  ticker = tickers[i]
  # Format the price dataframe: col = price referenced by ticker, row = dates
  prices = SP_data$Price[SP_data$Ticker == ticker]
  if (length(prices) == ndays){
    rets[as.character(ticker),] = prices[2:length(prices)]/prices[1:(length(prices)-1)] - 1
    #colnames(lrets) = as.Date(temp_df[-1,1],format="%m/%d/%Y")
    colnames(rets) = SP_data$Date[SP_data$Ticker == ticker][-1]
    }
}

##############################################################################################
##################################### CLUSTERING PART ########################################

# Step 1: clustering using k-medoids
rets2 = na.omit(rets) #488 stocks

#train_index = ceiling(0.75*ncol(rets2)) 
train_index = grep("2017-01-03", colnames(rets2))-1
rets2.train = rets2[,1:train_index]    #training data: first four years (2012-2016)
rets2.test = rets2[,-c(1:train_index)] #test data: fifth year (2017 - 2018)

avg.width = c() #apply k-means clustering on training data set
for (k in 4:100){
  rets.km = pam(rets2.train, k)
  avg.width[k] = rets.km$silinfo$avg.width
}
k.best <- which.max(avg.width)
# Plot of kmeans clustering performance: Avg Wigth vs K
plot(avg.width,type = 'b',xlab = "K",ylab = "Avg Width", main = "K-medoids Clustering Performance")
axis(1, k.best, paste("best",k.best,sep="\n"), col = "red", col.axis = "red")
#k.best = 98

# Step 2: Get the medoids
final.kmed = pam(rets2.test, k.best)
cluster.centroids = row.names(final.kmed$medoids)
rets.centroids = rets2[cluster.centroids,]
rets.centroids.train = rets.centroids[,1:train_index]
rets.centroids.test = rets.centroids[,-c(1:train_index)]

##############################################################################################
################################# PREPARE BENCHMARK ##########################################

# Take the S&P500 index quotes
start.date = '2012-01-01'
end.date = '2018-04-09'
# Import benchmark from yahoo finance
SP.data = BatchGetSymbols(tickers = '^GSPC', 
                          first.date = start.date,
                          last.date = end.date, 
                          cache.folder = file.path(tempdir(), 
                                                   'BGS_Cache') )
# Format the import to dataframe
SP.data.df = data.frame(SP.data$df.tickers[,'price.close'], row.names=SP.data$df.tickers[,'ref.date'])
colnames(SP.data.df) = 'close'
SP.close = SP.data.df$close

# Create a return dataframe from S&P500
SP.rets = SP.close[2:length(SP.close)]/SP.close[1:(length(SP.close)-1)] - 1
SP.rets.train = SP.rets[1:train_index]    #training data: 2012-2016
SP.rets.test = SP.rets[-c(1:train_index)] #test data: 2017-2018

##############################################################################################
############################## PREPARE MODIFIED BENCHMARK ####################################

SP.rets.mod = SP.rets
for (i in 1:(ndays-1)){
  if (SP.rets[i] < threshold){
    SP.rets.mod[i] = -threshold
    #SP.rets.mod[i] = -SP.rets.mod[i] #???
  }
}
SP.rets.mod.train = SP.rets.mod[1:train_index]    #training data: 2012-2016
SP.rets.mod.test = SP.rets.mod[-c(1:train_index)] #test data: 2017-2018

plot(SP.rets.mod, type='l', col="black", main="Returns of modified vs actual SP500")
lines(SP.rets, col="green")

SP.cumrets.mod = cumprod(1 + SP.rets.mod)
SP.cumrets = cumprod(1 + SP.rets)

##############################################################################################
################################# ALLOCATION PART: STATIC ####################################

####### ON TRAIN DATA
# Set the quadratic problem
X.train = t(data.matrix(rets.centroids.train))
Y.train.real = data.matrix(SP.rets.train)
Rinv = t(X.train) %*% X.train;
C = cbind(rep(1,k.best), diag(k.best))
b = c(1,rep(0,k.best))
d = t(Y.train.real) %*% X.train  
sol.replic = solve.QP(Dmat = Rinv, dvec = d, Amat = C, bvec = b, meq = 1)
weights.replic.real = sol.replic$solution

X.train = t(data.matrix(rets.centroids.train))
Y.train.mod = data.matrix(SP.rets.mod.train)
Rinv = t(X.train) %*% X.train;
C = cbind(rep(1,k.best), diag(k.best))
b = c(1,rep(0,k.best))
d = t(Y.train.mod) %*% X.train  
sol.replic = solve.QP(Dmat = Rinv, dvec = d, Amat = C, bvec = b, meq = 1)
weights.replic.mod = sol.replic$solution


# Compare to training set
SP.rets.replic.train.real = X.train %*% weights.replic.real
SP.rets.replic.train.mod = X.train %*% weights.replic.mod


plot(cumprod(1 + SP.rets.replic.train.real),ylim = c(1,2.3),type="l",col="black",xlab = "Time", ylab = "Cumulative Return", main = "Training Set: Static Portfolio vs S&P 500 Index")
lines(cumprod(1 + SP.rets.replic.train.mod),col='green')
lines(SP.cumrets.mod[1:train_index],col="blue")
lines(cumprod(1 + Y.train.real),col="red")
legend("topleft",legend = c("Real Replica","Mod Replica","Mod Index","Real Index"), col = c("black","green","blue","red"),lty = 1, title = "Legend", cex = 0.75)

#Mean and Variance of the returns of the Training Replication Strategy
mean(SP.rets.replic.train.real)
var(SP.rets.replic.train.real)

#Mean and Variance of the returns of the Modified Training Replication Strategy
mean(SP.rets.replic.train.mod)
var(SP.rets.replic.train.mod)

####### ON TEST DATA
# Now test the results
X.test = t(data.matrix(rets.centroids.test))
Y.test.real = data.matrix(SP.rets.test)
Y.test.mod = data.matrix(SP.rets.mod.test)

SP.rets.replic.test.real = X.test %*% weights.replic.real
SP.rets.replic.test.mod = X.test %*% weights.replic.mod

plot(cumprod(1 + SP.rets.replic.test.real),ylim = c(1,1.45),type="l",col="black",xlab = "Time", ylab = "Cumulative Return", main = "Testing Set: Static Portfolio vs S&P 500 Index")
lines(cumprod(1 + SP.rets.replic.test.mod),col='green')
lines(cumprod(1 + Y.test.mod),col="blue")
lines(cumprod(1 + Y.test.real),col="red")
legend("topleft",legend = c("Real Replica","Mod Replica","Mod Index","Real Index"), col = c("black","green","blue","red"),lty = 1, title = "Legend", cex = 0.75)


#Mean and Variance of the returns of the Test Replication Strategy
mean(SP.rets.replic.test.real)
var(SP.rets.replic.test.real)

#Mean and Variance of the returns of the Modified Test Replication Strategy
mean(SP.rets.replic.test.mod)
var(SP.rets.replic.test.mod)

##############################################################################################
################################# ALLOCATION PART: DYNAMIC ###################################


#### REAL CURVE TO FIT
#train model on first 4 years, then test on each month afterwards
#shift the training set by one month as we go along
monthly = seq(0,ndays,by=21)
last_year = monthly[(length(monthly)-15):length(monthly)]
port_weights.dynamic.real = data.frame(matrix(,nrow = k.best))
SP.rets.replic.dynamic.real = c()

for (i in 1:(length(last_year)-1)){
  #every 21 days
  training = (1+21*(i-1)):last_year[i]
  test = (last_year[i]+1):last_year[i+1]
  
  # return of portfolio
  rets.centroids.train2 = rets.centroids[,training]  
  rets.centroids.test2 = rets.centroids[,test]       
  
  # return of S&P 500
  SP.rets.train2 = SP.rets[training]    
  SP.rets.test2 = SP.rets[test]        
  
  # Set and solve the quadratic problem
  X = t(data.matrix(rets.centroids.train2))
  Y = data.matrix(SP.rets.train2)
  Rinv = t(X) %*% X;
  #pd_D_mat = nearPD(Rinv)$mat
  # If no shorting
  # C = cbind(rep(1,k.best), diag(k.best))
  # If shorting
  C = as.matrix(rep(1,k.best))
  # If no shorting
  # b = c(1, rep(0,k.best))
  # If shorting
  b = 1
  
  d = t(Y) %*% X  
  sol.replic = solve.QP(Dmat = Rinv, dvec = d, Amat = C, bvec = b, meq = 1)
  weights.replic.dynamic.real = sol.replic$solution
  port_weights.dynamic.real[,i] = weights.replic.dynamic.real
  
  # Now test the results
  X.test.real = t(data.matrix(rets.centroids.test2))
  # Get the total log returns of the portfolio over the new period and save it
  SP.rets.replic.dynamic.real = c(SP.rets.replic.dynamic.real, X.test.real %*% weights.replic.dynamic.real)
}

#### MODIFIED CURVE TO FIT
monthly = seq(0,ndays,by=21)
last_year = monthly[(length(monthly)-15):length(monthly)]
port_weights.dynamic.mod = data.frame(matrix(,nrow = k.best))
SP.rets.replic.dynamic.mod = c()

for (i in 1:(length(last_year)-1)){
  #every 21 days
  training = (1+21*(i-1)):last_year[i]
  test = (last_year[i]+1):last_year[i+1]
  
  # return of portfolio
  rets.centroids.train2 = rets.centroids[,training]  
  rets.centroids.test2 = rets.centroids[,test]       
  
  # return of S&P 500
  SP.rets.mod.train2 = SP.rets.mod[training]    
  
  # Set and solve the quadratic problem
  X = t(data.matrix(rets.centroids.train2))
  Y = data.matrix(SP.rets.mod.train2)
  Rinv = t(X) %*% X;
  #pd_D_mat = nearPD(Rinv)$mat
  # If no shorting
  # C = cbind(rep(1,k.best), diag(k.best))
  # If shorting
  C = as.matrix(rep(1,k.best))
  # If no shorting
  # b = c(1, rep(0,k.best))
  # If shorting
  b = 1
  
  d = t(Y) %*% X  
  sol.replic = solve.QP(Dmat = Rinv, dvec = d, Amat = C, bvec = b, meq = 1)
  weights.replic.dynamic.mod = sol.replic$solution
  port_weights.dynamic.mod[,i] = weights.replic.dynamic.mod
  
  # Now test the results
  X.test.mod = t(data.matrix(rets.centroids.test2))
  # Get the total log returns of the portfolio over the new period and save it
  SP.rets.replic.dynamic.mod = c(SP.rets.replic.dynamic.mod, X.test.mod %*% weights.replic.dynamic.mod)
}


plot(cumprod(1 + SP.rets.replic.dynamic.real),type="l",col="black",xlab="time", ylab="Cumulative Returns", ylim = c(0.9,1.5), main="Replica vs SP Index with Dynamic portfolio (Real and Modified Index)")
lines(cumprod(1 + SP.rets.replic.dynamic.mod),col="green")
lines(cumprod(1 + SP.rets.mod.test),col="blue")
lines(cumprod(1 + SP.rets.test),col="red")
legend("topleft",legend = c("Real Replica","Mod Replica", "Mod Index", "Real Index"), col = c("black","green","blue","red"),lty = 1, title = "Legend", cex = 0.75)

SP.cumrets.replic.dynamic.mod = c(1,cumprod(1+SP.rets.replic.dynamic.mod))

#Mean and Variance of the returns of the dynamic replication
mean(SP.rets.replic.dynamic.real)
var(SP.rets.replic.dynamic.real)

#Mean and Variance of the returns of the modified dynamic replication
mean(SP.rets.replic.dynamic.mod)
var(SP.rets.replic.dynamic.mod)

SP.rets.test.mod = SP.rets.mod[last_year[1]:last_year[16]]
SP.mod = c(1,cumprod(1+SP.rets.test.mod))

#porfolio
mean(SP.rets.replic.dynamic)
var(SP.rets.replic.dynamic)



##############################################################################################
########################## CALIBRATION PART: CHANGE BENCHMARK ################################

threshold = -0.03
SP.rets.mod = SP.rets

for (i in 1:(ndays-1)){
  if (SP.rets.mod[i] < threshold){
    SP.rets.mod[i] = -threshold
  }
}
plot(SP.rets.mod,type="l",col="red")
lines(SP.rets,col="green")

plot(cumprod(1+SP.rets.mod),type="l",col="blue")
lines(cumprod(1+SP.rets),col="green")



##############################################################################################
######################## CALIBRATION PART: DYNAMIC ALLOCATION ################################

# monthly = seq(0,1575,by=21)
# last_year = monthly[(length(monthly)-12):length(monthly)]
# port_weights = data.frame(matrix(,nrow = k.best))
# SP.rets.replic = c()
# 
# for (i in 1:(length(last_year)-1)){
#   #every 21 days
#   training = (1+21*(i-1)):last_year[i]
#   test = (last_year[i]+1):last_year[i+1]
#   
#   #log return of portfolio
#   rets.centroids.train2 = rets.centroids[,training]  
#   rets.centroids.test2 = rets.centroids[,test]       
#   
#   #log return of S&P 500
#   SP.rets2.train2 = SP.rets.mod[training]    
#   SP.rets2.test2 = SP.rets.mod[test]        
#   
#   # Set and solve the quadratic problem
#   X = t(data.matrix(rets.centroids.train2))
#   Y = data.matrix(SP.rets2.train2)
#   Rinv = t(X) %*% X;
#   #pd_D_mat = nearPD(Rinv)$mat
#   # If no shorting
#   # C = cbind(rep(1,k.best), diag(k.best))
#   # If shorting
#   C = as.matrix(rep(1,k.best))
#   # If no shorting
#   # b = c(1, rep(0,k.best))
#   # If shorting
#   b = 1
#   
#   d = t(Y) %*% X  
#   sol.replic = solve.QP(Dmat = Rinv, dvec = d, Amat = C, bvec = b, meq = 1)
#   weights.replic = sol.replic$solution
#   port_weights[,i] = weights.replic
#   
#   # Now test the results
#   X.test = t(data.matrix(rets.centroids.test2))
#   Y.test = data.matrix(SP.rets2.test2)
#   # Get the total log returns of the portfolio over the new period and save it
#   SP.rets.replic = c(SP.rets.replic, X.test %*% weights.replic)
# }

# Now try to see how bad it is in terms of close price
SP.rets.test.mod = SP.rets.mod[last_year[1]:last_year[13]]
SP.mod = c(1)
for (k in 1:length(SP.rets.test.mod)){
  SP.mod[k+1] = SP.mod[k] * (1 + SP.rets.test.mod[k])
}

plot(SP.replic.dynamic.cumret,type="l",col="black",xlab="time", ylab="Cumulative Returns", ylim = c(0.9,1.5), main="Dynamic Portfolio vs S&P 500 Index vs Calibrated S&P 500 Index")
lines(SP.real.test.dynamic.cumret,col="green")
lines(SP.mod,col="blue")
legend("topleft",legend = c("Portfolio","Index", "Cal. Index"), col = c("black","green","blue"),lty = 1, title = "Legend", cex = 0.75)


###############################################################################################
############################# EXTRA ALLOCATION PART: HYBRID ###################################

# Set the quadratic problem without non-negative constraints
# shorting is allowed
# This part is about making an hybrid problem between the prices and the returns
centroid.tickers = row.names(rets.centroids)
Prices = data.frame(matrix(, ncol=(ndays-1), nrow=0))

for (i in 1:length(centroid.tickers)){
  centroid.ticker = centroid.tickers[i]
  # Format the price dataframe: col = price referenced by ticker, row = dates
  prices = SP_data$Price[SP_data$Ticker == centroid.ticker]
  Prices[as.character(centroid.ticker),] = prices[2:length(prices)]
  colnames(Prices) = SP_data$Date[SP_data$Ticker == centroid.ticker][-1]
}

P = as.matrix(Prices[,1:train_index])

X = data.matrix(rets.centroids.train)
Y = data.matrix(SP.rets2.train)

lambdas = seq(10^-20,10^-15,length.out = 1000)

mses = c()
for (i in 1:length(lambdas)){
  lambda = lambdas[i]
Rinv = X %*% t(X)
PPt = P %*% t(P)
D = Rinv + lambda*PPt

YL = Y
YP = SP.close[2:(train_index+1)]
d = t(X %*% YL) + lambda*t(P %*% YP)
#A = cbind(rep(1,k.best), diag(k.best))
#b = c(1,rep(0,k.best))
b = 1
A = as.matrix(rep(1,k.best))
#d = t(Y) %*% X  
sol.replic = solve.QP(Dmat = D, dvec = d, Amat = A, bvec = b, meq = 1)
weights.replic = sol.replic$solution



# Now test the results
X.test = t(data.matrix(rets.centroids.test))
Y.test = data.matrix(SP.rets2.test)
SP.rets.replic = X.test %*% weights.replic
# Are the results consistent?
#plot(SP.lrets.replic,type="l",col="red")
#lines(Y.test,col="green")
#sum of squared error
#sum((Y.test[,1] - SP.lrets.replic[,1])^2)

# Now try to see how bad it is in terms of close price
SP.real.test = SP.close[-c(1:train_index)]
SP.replic = c(SP.real.test[1])
for (k in 1:length(SP.lrets.replic)){
  SP.replic[k+1] = SP.replic[k] * exp(SP.rets.replic[k])
}
mses[i] = mean((SP.real.test - SP.replic)^2)
}

lambdas[which.min(mses)]

plot(mses)

plot(SP.replic,type="l",col="red", ylim=c(1300,3000))
lines(SP.real.test,col="green")

